  <p style="text-align: center;"><img alt="" class="" src="https://kinodivbox.github.io/css_js/logo3.png" style="width: 100%; height: auto;" /></p>

<div class="container">
<h1 style="text-align: center;"><a href="https://kinodivbox.github.io/kinodivbox_officialinstallhelper.html" target="_blank"><span style="font-size:28px;"><strong>Установка расширения <span style="color:#ff6c00">KinoDivBox</span></strong></span></a></h1>
</div>
